def absolute_square(num1, num2):
    result = abs(num1 - num2)
    result *= result
    return result